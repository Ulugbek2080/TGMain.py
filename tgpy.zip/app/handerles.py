from aiogram import F, Router
from aiogram.types import Message, FSInputFile
from aiogram.filters import CommandStart, Command, state
import app.keyboards as kb
import app.slovar as slovar
from aiogram.types import Message
from aiogram.fsm.context import FSMContext



router = Router()

@router.message(CommandStart())
async def cmd_start(message: Message):
    await message.answer(
        'Добро пожаловать! Выберите язык \nWelcome! Select a language',
        reply_markup=kb.get_language_keyboard())

@router.message(F.text.in_([
    'Русский язык 🇷🇺',
    'English language 🇬🇧',
    '中文 🇨🇳',
    "O'zbek tili 🇺🇿"
]))
async def language_selected(message: Message, state: FSMContext):

    text = message.text
    language_map = {
        'Русский язык 🇷🇺': 'ru',
        'English language 🇬🇧': 'en',
        '中文 🇨🇳': 'ch',
        "O'zbek tili 🇺🇿": 'uz'
    }

    selected_lang = language_map.get(text, 'ru')
    user_id = message.from_user.id
    await state.update_data(user_id=user_id, language=selected_lang)

    PolitikaBota = slovar.get_dictionary('ПрочитатьПолитикуБота', selected_lang)
    reply_markup = kb.get_consent_keyboard(selected_lang)
    await message.answer(
        PolitikaBota,
        reply_markup=reply_markup)
    file_path = "E:/py/Запрещенные товары.docx"
    try:
        doc = FSInputFile(file_path, filename="Offer.docx")
        await message.answer_document(document=doc)
    except Exception as e:
        print(f"Ошибка отправки документа: {e}")

#Получение контакта
@router.message(F.contact)
async def some_handler(message: Message, state: FSMContext):
    Dostup = True
    lang = languageUser(message.from_user.id)
    #Проверка контакта из 1С message.text
    #data = await state.get_data()
    #lang = data.get("language")
    if Dostup:
        after_auth = slovar.get_dictionary('ПриветствиеПослеАвторизации', lang)
        reply_markup = kb.get_main_menu_keyboard(lang)
        await message.answer(after_auth, reply_markup=reply_markup)

# Приветствие
@router.message(F.text)
async def handle_all_messages(message: Message, state: FSMContext):
    lang = languageUser(message.from_user.id)
    text = message.text

    if text == slovar.get_dictionary('Согласен', lang):
        await message.answer(
            slovar.get_dictionary('Приветствие', lang),
            reply_markup=kb.get_contact_request_keyboard(lang)
        )

    elif text == slovar.get_dictionary('НеДаюСогласия', lang):
        await message.answer(
            slovar.get_dictionary('ТекстПользовательНеДалСоглаия', lang),
            reply_markup=kb.get_consent_keyboard(lang)
        )

    elif text == slovar.get_dictionary('Отчеты', lang):
        await message.answer(
            slovar.get_dictionary('ВыборДействия', lang),
            reply_markup=kb.get_report_keyboard(lang)
        )

    elif text == slovar.get_dictionary('Сервисы', lang):
        await message.answer(
            slovar.get_dictionary('ВыборДействия', lang),
            reply_markup=kb.get_services_keyboard(lang)
        )

    elif text == slovar.get_dictionary('Назад', lang):
        await message.answer(
            slovar.get_dictionary('ВыборДействия', lang),
            reply_markup=kb.get_main_menu_keyboard(lang)
        )

    elif text == slovar.get_dictionary('ПомощьОператора', lang):
        await message.bot.send_contact(
            chat_id=message.chat.id,
            phone_number="+998938743434",
            first_name="ABUSAHIYTASHKENT1"
        )

    elif text == slovar.get_dictionary('ТоварыВПути', lang):
        await message.answer(
            slovar.get_dictionary('ТоварыВПути', lang)
        )

    elif text == slovar.get_dictionary('ВсеТовары', lang):
        await message.answer(
            "📦 Вот список всех товаров..."
        )

    elif text == slovar.get_dictionary('ПрибывшиеТовары', lang):
        await message.answer(
            "📥 Товары, которые прибыли:"
        )

    elif text == slovar.get_dictionary('ПолученныеТовары', lang):
        await message.answer(
            "📬 Полученные товары:"
        )

    elif text == slovar.get_dictionary('МоиКоды', lang):
        await message.answer(
            "🔐 Ваши коды:"
        )

    elif text == slovar.get_dictionary('АдресаСкладов', lang):
        await message.answer(
            slovar.get_dictionary('ТекстДляАдресовСклада', lang)
        )

    elif text == slovar.get_dictionary('СписокЗапрещенныхТоваров', lang):
        file_path = "E:/py/Запрещенные товары.docx"
        doc = FSInputFile(file_path, filename="Offer.docx")
        await message.answer_document(document=doc)


def languageUser(id):
    lang = 'ru'
    return lang